# Multi-Agent 研发流程 — 迁移指南

## 文件清单

```
~/.claude/
├── agents/
│   ├── dev-orchestrator.md          # 主协调器（sonnet）
│   ├── requirement-explorer.md      # 需求发散探索（sonnet）
│   ├── spec-analyst.md              # 需求分析（haiku + effort:low）
│   ├── spec-designer.md             # 技术设计（sonnet）
│   ├── spec-planner.md              # 任务拆分（haiku + effort:low）
│   ├── coder.md                     # TDD 编码（sonnet）
│   ├── tester.md                    # 补充测试（haiku + effort:low）
│   ├── code-reviewer.md             # 代码审查（sonnet）
│   ├── dashboard.md                 # 大盘分析（haiku + effort:low + bypassPermissions）
│   └── README.md                    # 本文件
├── hooks/
│   └── agent-event-logger.js        # Hook 脚本
├── agent-metrics/                   # 运行时自动生成，无需复制
├── settings.json                    # 需合并 hooks
└── CLAUDE.md                        # 需追加引导段落
```

---

## 迁移步骤

### Step 1: 打包

```bash
tar -czf claude-multi-agent.tar.gz \
  -C ~ \
  .claude/agents/dev-orchestrator.md \
  .claude/agents/requirement-explorer.md \
  .claude/agents/spec-analyst.md \
  .claude/agents/spec-designer.md \
  .claude/agents/spec-planner.md \
  .claude/agents/coder.md \
  .claude/agents/tester.md \
  .claude/agents/code-reviewer.md \
  .claude/agents/dashboard.md \
  .claude/agents/README.md \
  .claude/hooks/agent-event-logger.js
```

### Step 2: 解压 + 权限

```bash
tar -xzf claude-multi-agent.tar.gz -C ~
mkdir -p ~/.claude/agent-metrics
chmod +x ~/.claude/hooks/agent-event-logger.js
```

### Step 3: 合并 settings.json hooks

追加到 `~/.claude/settings.json` 的 `hooks` 中（已有同名 hook 则在其 `hooks` 数组中追加）：

```json
"SubagentStart": [
  { "hooks": [{ "type": "command", "command": "node ~/.claude/hooks/agent-event-logger.js --event-type SubagentStart" }] }
],
"SubagentStop": [
  { "hooks": [{ "type": "command", "command": "node ~/.claude/hooks/agent-event-logger.js --event-type SubagentStop" }] }
]
```

PreToolUse/PostToolUse 在已有 hooks 数组中追加一条：
```json
{ "type": "command", "command": "node ~/.claude/hooks/agent-event-logger.js --event-type PreToolUse" }
{ "type": "command", "command": "node ~/.claude/hooks/agent-event-logger.js --event-type PostToolUse" }
```

### Step 4: settings.json env 检查

- 删除 `CLAUDE_CODE_SUBAGENT_MODEL`（如有），否则覆盖所有子 agent 的 model 配置
- 确保有 `CLAUDE_CODE_EXPERIMENTAL_AGENT_TEAMS: "1"`（SendMessage 复用依赖此项）

### Step 5: 合并 CLAUDE.md

末尾追加：

```markdown
## 多 Agent 研发模式
当用户意图是"开发需求/实现功能/做一个完整的 feature"时，建议使用多 Agent 协作模式：
```bash
claude --agent dev-orchestrator
```
适用场景：新功能开发、复杂需求实现。不适用于：简单问答、小 bug 修复、代码解释。
```

### Step 6: Shell alias（可选）

```bash
echo 'alias dev="claude --agent dev-orchestrator"' >> ~/.zshrc
```

---

## 前置依赖

| 依赖 | 检查命令 | 安装 |
|------|---------|------|
| Node.js | `node --version` | brew install node |
| Claude Code CLI | `claude --version` | npm install -g @anthropic-ai/claude-code |
| Git | `git --version` | brew install git |
| token-pilot | `npx token-pilot --help` | 自动下载，无需手动安装 |

---

## Model 映射

agent 文件里的 `model` 字段是 alias，实际模型由 settings.json env 决定：

| alias | 环境变量 |
|-------|---------|
| sonnet | ANTHROPIC_DEFAULT_SONNET_MODEL |
| haiku | ANTHROPIC_DEFAULT_HAIKU_MODEL |
| opus | ANTHROPIC_DEFAULT_OPUS_MODEL |

改模型：编辑 settings.json 中对应环境变量即可，agent 文件不用动。
