#!/usr/bin/env node
/**
 * Agent 事件记录器
 * 
 * 通过 Claude Code hooks 捕获事件，按项目+需求标识隔离写入 JSONL。
 * 
 * 性能优化：git 结果缓存到 /tmp，避免每次 hook 触发都执行 git 命令。
 * 
 * 用法：node ~/.claude/hooks/agent-event-logger.js --event-type <EventType>
 */

const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const { execSync } = require('child_process');

const METRICS_BASE = path.join(process.env.HOME, '.claude', 'agent-metrics');
const CACHE_TTL_MS = 60000; // 缓存 60 秒

/**
 * 获取当前工作目录的 hash（用于缓存 key）
 */
function getCwdHash() {
  return crypto.createHash('md5').update(process.cwd()).digest('hex').slice(0, 8);
}

/**
 * 带缓存的项目上下文获取
 */
function getProjectContext() {
  const cacheFile = `/tmp/claude-agent-ctx-${getCwdHash()}`;

  // 尝试读缓存
  try {
    const stat = fs.statSync(cacheFile);
    if (Date.now() - stat.mtimeMs < CACHE_TTL_MS) {
      const cached = JSON.parse(fs.readFileSync(cacheFile, 'utf8'));
      return cached;
    }
  } catch { /* cache miss */ }

  // 缓存未命中，执行 git 命令
  let project = 'unknown-project';

  try {
    const remote = execSync('git remote get-url origin 2>/dev/null', { encoding: 'utf8', timeout: 3000 }).trim();
    if (remote) {
      // 只取仓库名（最后一段），不取 group
      // ssh://git@host:port/group/repo.git → repo
      // git@host:group/repo.git → repo
      const match = remote.match(/\/([^/]+?)(?:\.git)?$/);
      if (match) project = match[1];
    }
  } catch {
    try {
      project = path.basename(process.cwd());
    } catch { /* ignore */ }
  }

  project = project.replace(/[^a-zA-Z0-9_\-\.]/g, '_');

  // 写缓存
  const result = { project };
  try { fs.writeFileSync(cacheFile, JSON.stringify(result)); } catch { /* ignore */ }

  return result;
}

/**
 * 获取当前需求标识（从 .current-requirement 文件读取，已经很快不需要缓存）
 */
function getRequirement() {
  const reqFile = path.join(METRICS_BASE, '.current-requirement');
  try {
    if (fs.existsSync(reqFile)) {
      return fs.readFileSync(reqFile, 'utf8').trim();
    }
  } catch { /* ignore */ }
  return 'unknown';
}

/**
 * 从子 agent transcript 文件中统计工具调用
 */
function analyzeTranscript(transcriptPath) {
  const toolCalls = {};
  let totalCalls = 0;

  try {
    if (!fs.existsSync(transcriptPath)) return { toolCalls, totalCalls };

    const lines = fs.readFileSync(transcriptPath, 'utf8').split('\n').filter(Boolean);
    for (const line of lines) {
      try {
        const entry = JSON.parse(line);
        if (entry.type === 'tool_use' || entry.type === 'tool_result') {
          const toolName = entry.name || entry.tool_name || '';
          if (toolName) {
            toolCalls[toolName] = (toolCalls[toolName] || 0) + 1;
            totalCalls++;
          }
        }
        if (entry.type === 'assistant' && Array.isArray(entry.message?.content)) {
          for (const block of entry.message.content) {
            if (block.type === 'tool_use') {
              const toolName = block.name || '';
              if (toolName) {
                toolCalls[toolName] = (toolCalls[toolName] || 0) + 1;
                totalCalls++;
              }
            }
          }
        }
      } catch { /* skip malformed lines */ }
    }
  } catch { /* file read error */ }

  return { toolCalls, totalCalls };
}

// 获取项目上下文（带缓存）
const { project } = getProjectContext();
const requirement = getRequirement();
const metricsDir = path.join(METRICS_BASE, project, requirement);
const eventsFile = path.join(metricsDir, 'hook-events.jsonl');

if (!fs.existsSync(metricsDir)) {
  fs.mkdirSync(metricsDir, { recursive: true });
}

// 从命令行参数获取事件类型
const args = process.argv.slice(2);
const eventTypeIdx = args.indexOf('--event-type');
const eventType = eventTypeIdx !== -1 ? args[eventTypeIdx + 1] : 'Unknown';

// 从 stdin 读取事件数据
let input = '';
process.stdin.setEncoding('utf8');
process.stdin.on('data', (chunk) => { input += chunk; });
process.stdin.on('end', () => {
  try {
    const payload = input.trim() ? JSON.parse(input) : {};

    const record = {
      timestamp: new Date().toISOString(),
      eventType: eventType,
      sessionId: payload.session_id || process.env.CLAUDE_SESSION_ID || 'unknown',
      project: project,
      requirement: requirement,
    };

    switch (eventType) {
      case 'SubagentStart':
        record.agentType = payload.agent_type || 'unknown';
        record.agentId = payload.agent_id || '';
        break;

      case 'SubagentStop':
        record.agentType = payload.agent_type || 'unknown';
        record.agentId = payload.agent_id || '';
        record.transcriptPath = payload.transcript_path || '';
        if (payload.transcript_path) {
          const { toolCalls, totalCalls } = analyzeTranscript(payload.transcript_path);
          record.toolCalls = toolCalls;
          record.totalToolCalls = totalCalls;
        }
        break;

      case 'PreToolUse':
        record.toolName = payload.tool_name || '';
        record.agentType = payload.agent_type || 'main';
        record.agentId = payload.agent_id || '';
        break;

      case 'PostToolUse':
        record.toolName = payload.tool_name || '';
        record.agentType = payload.agent_type || 'main';
        record.agentId = payload.agent_id || '';
        break;

      default:
        break;
    }

    fs.appendFileSync(eventsFile, JSON.stringify(record) + '\n');
  } catch (err) {
    const errLog = path.join(METRICS_BASE, 'error.log');
    try {
      fs.appendFileSync(errLog, `${new Date().toISOString()} [${project}/${requirement}] ${eventType} ERROR: ${err.message}\n`);
    } catch { /* truly silent */ }
  }
});
